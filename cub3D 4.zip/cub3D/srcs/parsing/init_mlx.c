/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   init_mlx.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: adiouane <adiouane@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/25 19:28:00 by adiouane          #+#    #+#             */
/*   Updated: 2022/08/25 19:28:25 by adiouane         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# include <cub3D.h>

void	init_window(t_map *data)
{
	data->mlx = mlx_init();
	data->mlx_win = mlx_new_window(data->mlx, data->width * 64, data->height * 64, "cub3D 2D");
	data->wall = mlx_xpm_file_to_image(data->mlx,
			"XpmPack/wall.xpm", &data->width, &data->height);
	data->background = mlx_xpm_file_to_image(data->mlx,
			"XpmPack/background.xpm", &data->width, &data->height);
	data->player = mlx_xpm_file_to_image(data->mlx,
			"XpmPack/player.xpm", &data->width, &data->height);
}
