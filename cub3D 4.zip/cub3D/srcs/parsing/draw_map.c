/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   draw_map.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: adiouane <adiouane@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/25 19:30:00 by adiouane          #+#    #+#             */
/*   Updated: 2022/08/25 20:46:40 by adiouane         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <cub3D.h>

void	draw_map(t_map	*data);


void	ft_move_player(t_map *data, int direction)
{
	int	i;
	int	j;

	i = 0;
	j = 0;
	if (direction == KEY_UP)
		i = -1;
	if (direction == KEY_DOWN)
		i = 1;
	if (direction == KEY_LEFT)
		j = -1;
	if (direction == KEY_RIGHT)
		j = 1;
	data->draw_map[data->y][data->x] = '0';
	data->y += i;
	data->x += j;
	data->draw_map[data->y][data->x] = 'N';
	draw_map(data);
}

int	ft_check_move2(int keycode, t_map *data)
{
	if (keycode == KEY_UP)
	{
		if (data->draw_map[data->y - 1][data->x] == '1')
			return (0);
	}
	if (keycode == KEY_DOWN)
	{
		if (data->draw_map[data->y + 1][data->x] == '1')
			return (0);
	}
	return (1);
}

int	ft_check_move(int keycode, t_map *data)
{
	if (keycode == KEY_RIGHT)
	{
		data->direction = RIGHT;
		if (data->draw_map[data->y][data->x + 1] == '1')
			return (0);
	}
	if (keycode == KEY_LEFT)
	{
		data->direction = LEFT;
		if (data->draw_map[data->y][data->x - 1] == '1')
			return (0);
	}
	return (1);
}

int	ft_move_hook(int keycode, t_map *data)
{
	if ((ft_check_move(keycode, data) == 1)
		&& (ft_check_move2(keycode, data) == 1))
		ft_move_player(data, keycode);
	return (1);
}

int	ft_move(int keycode, t_map *data)
{
	if (keycode == KEY_ESC)
		exit(0);
	if (keycode == KEY_DOWN)
		ft_move_hook(keycode, data);
	if (keycode == KEY_LEFT)
		ft_move_hook(keycode, data);
	if (keycode == KEY_RIGHT)
		ft_move_hook(keycode, data);
	if (keycode == KEY_UP)
		ft_move_hook(keycode, data);
	return (0);
}

void	draw_map(t_map	*data)
{
	int i = 0;
	int j = 0;
	while (data->draw_map[i])
	{
		j = 0;
		while (data->draw_map[i][j])
		{
			mlx_put_image_to_window(data->mlx, data->mlx_win,
				data->background, j * 64, i * 64);
			if (data->draw_map[i][j] == '1')
				mlx_put_image_to_window(data->mlx, data->mlx_win,
					data->wall, j * 64, i * 64);
			if (data->draw_map[i][j] == 'N' || data->draw_map[i][j] == 'S'
				|| data->draw_map[i][j] == 'W' || data->draw_map[i][j] == 'E')
				{
					mlx_put_image_to_window(data->mlx, data->mlx_win,
						data->player, j * 64, i * 64);
					data->x = j;
					data->y = i;
					// draw_line(data->mlx, data->mlx_win, data->x, data->y, data->x + 64, data->y, 0x00FF00);		
				}
			j++;
		}
		i++;
	}
}
