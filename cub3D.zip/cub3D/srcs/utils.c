

// this function is used to print the error message and exit the program
while(get_next_line(fd, &matrix))
	{
		if (matrix[0][0] == 'R')
			read_resolution(matrix);
		else if (matrix[0][0] == 'N')
			read_north(matrix);
		else if (matrix[0][0] == 'S')
			read_south(matrix);
		else if (matrix[0][0] == 'W')
			read_west(matrix);
		else if (matrix[0][0] == 'E')
			read_east(matrix);
		else if (matrix[0][0] == 'F')
			read_floor(matrix);
		else if (matrix[0][0] == 'C')
			read_ceiling(matrix);
		else if (matrix[0][0] == ' ')
			read_map(matrix);
		else
			error_msg("Error\n");
	}
    close(fd);
    return (0);
}
/*
    this function is used to read the resolution of the map
    the resolution is the size of the map file in pixels (width and height) and is specified by the R command in the map filename. 
    the resolution is specified by two integers separated by a space.
    the first integer is the width and the second integer is the height.
    the resolution must be at least 200x200 pixels.
*/