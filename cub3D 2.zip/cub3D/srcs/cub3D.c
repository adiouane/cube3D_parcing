/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   cub3D.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: adiouane <adiouane@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/15 19:11:31 by omanar            #+#    #+#             */
/*   Updated: 2022/08/22 03:01:46 by adiouane         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <cub3D.h>

void	check_map(t_map *map)
{
	// we will check if the map is valid by checking if the empty 0 charachters is serounded by walls 1 and all map is surrounded by walls 1
	int		i;
	int		j;

	i = 0;
	while (i < map->height)
	{
		j = 0;
		while (j < map->width)
		{
			if (ft_strncmp(&map->map[i][j], "0", 1) == 0)
			{
				if (i == 0 || i == map->height - 1 || j == 0 || j == map->width - 1)
					error("Error\nMap is not valid\n", "Map is not valid\n");
			}
			j++;
		}
		i++;
	}
}

void	save_map_dementions(t_map *map)
{
	map->width = ft_strlen(map->map[6]);
	map->height = 0;
	int i = 6;
	// width is the big line of the map
	// height is the number of lines of the map
	while(map->map[i])
	{
		if ((int)ft_strlen(map->map[i]) > map->width)
			map->width = ft_strlen(map->map[i]);
		map->height++;
		i++;
	}
	printf("width: %d\n", map->width);
	printf("height: %d\n", map->height);
	
}
void	check_colors(t_map *map)
{
	int i = 0;
	char **F;

	F = ft_split(map->floor_color+1, ',');
	while (i < 3)
	{
		if (ft_atoi(F[i]) > 255 || ft_atoi(F[i]) < 0)
			error("Invalid color\n");
		i++;
	}
	free(F);
	i = 0;
	char **C;
	C = ft_split(map->ceiling_color+1, ',');
	while (i < 3)
	{
		if (ft_atoi(C[i]) > 255 || ft_atoi(C[i]) < 0)
			error("Invalid color\n");
		i++;
	}
	free(C);
}

int		check_if_paths_are_deplicated(t_map *map, char *str)
{
	int i;
	int is_deplicated = 0;

	i = 0;
	while(map->map[i])
	{
		if (ft_strncmp(ft_split(map->map[i], ' ')[0], str, ft_strlen(str)) == 0)
			is_deplicated++;
		i++;
	}
	return (is_deplicated);
}

void	check_deplicated(t_map *map)
{
	if (check_if_paths_are_deplicated(map, "NO") > 1)
		error("Error: NO path is deplicated\n");
	if (check_if_paths_are_deplicated(map, "SO") > 1)
		error("Error: SO path is deplicated\n");
	if (check_if_paths_are_deplicated(map, "WE") > 1)
		error("Error: WE path is deplicated\n");
	if (check_if_paths_are_deplicated(map, "EA") > 1)
		error("Error: EA path is deplicated\n");
	if (check_if_paths_are_deplicated(map, "F") > 1)
		error("Error: F path is deplicated\n");
	if (check_if_paths_are_deplicated(map, "C") > 1)
		error("Error: C path is deplicated\n");
}

void	ckeck_paths_exists_with_open(t_map *map)
{
	int fd;

	if ((fd = open(map->no, O_RDONLY)) == -1)
		exit_error("Error: no path", map->no);
	close(fd);
	if ((fd = open(map->so, O_RDONLY)) == -1)
		exit_error("Error: so path", map->so);
	close(fd);
	if ((fd = open(map->we, O_RDONLY)) == -1)
		exit_error("Error: we path", map->we);
	close(fd);
	if ((fd = open(map->ea, O_RDONLY)) == -1)
		exit_error("Error: ea path", map->ea);
	close(fd);
}

void	save_maps_info(t_map *map)
{
	int i;
	int j;
	
	i = 0;
	while (map->map[i])
	{
		j = 0;
		while (map->map[i][j])
		{
			if (ft_strncmp(&map->map[i][j], "NO", 2) == 0)
				map->no = ft_strdup(map->map[i]);
			if (ft_strncmp(&map->map[i][j], "SO", 2) == 0)
				map->so = ft_strdup(map->map[i]);
			if (ft_strncmp(&map->map[i][j], "WE", 2) == 0)
				map->we = ft_strdup(map->map[i]);
			if (ft_strncmp(&map->map[i][j], "EA", 2) == 0)
				map->ea = ft_strdup(map->map[i]);
			if (ft_strncmp(&map->map[i][j], "F", 1) == 0)
				map->floor_color = ft_strdup(map->map[i]);
			if (ft_strncmp(&map->map[i][j], "C", 1) == 0)
				map->ceiling_color = ft_strdup(map->map[i]);
			j++;
		}
		i++;
	}
}

void	check_size(char **map)
{
	int i = 0;
	while(ft_strncmp(map[i], "1", 1) != 0)
		i++;
	if (i > 6)
		error("Error: to many paths\n");
}

char	**ft_set_map(int fd)
{
	char	*stored;
	char	*buff;
	char	**matrix;
	int		i;

	stored = ft_strdup("");
	if (fd < 0)
		error("Error fix 3your map\n");
	buff = malloc((4096 + 1) * sizeof(char));
	if (!buff)
		return (NULL);
	i = read(fd, buff, 4096);
	// if (i == -1 || !i || buff[0] == '\n' || buff[i - 1] == '\n')
	// {
	// 	free(buff);
	// 	ft_exit();
	// }
	buff[i] = '\0';
	stored = ft_strjoine(stored, buff);
	free(buff);
	matrix = ft_split(stored, '\n');
	free(stored);
	if (!matrix)
		ft_exit();
	i = 0;
	while (matrix[i])
	{
		printf("%s\n", matrix[i]);
		i++;
	}
	// check_map(matrix, data);
	return (matrix);
}

void	parsing(char *str)
{
	int		fd;
	char	*ext;
	t_map	data;

	ext = ft_strrchr(str, '.');
	if (ft_strncmp(ext, ".cub\0", 5))
		exit_error("invalid file extension", ext);
	fd = open(str, O_RDONLY);
	if (fd == -1)
		exit_strerr(str, errno);
	data.map = ft_set_map(fd);
	check_size(data.map);
	check_deplicated(&data);
	save_maps_info(&data);
	check_colors(&data);
	save_map_dementions(&data);
	// ckeck_paths_exists_with_open(&data);
	check_map(&data);
	// printf("%s\n", data.no);
	// printf("%s\n", data.so);
	// printf("%s\n", data.we);
	// printf("%s\n", data.ea);
	// printf("%s\n", data.floor_color);
	// printf("%s\n", data.ceiling_color);
	close(fd);
	// printf("Everything looks good\n");
}

int	main(int ac, char **av)
{
	if (ac != 2)
	{
		printf("Usage: ./cub3D <filename.cub>\n");
		return (0);
	}
	parsing(av[1]);
	return (0);
}
